exports = async function () {

  // Supply projectID and clusterNames...
  const projectID = '<Project ID>';
  const clusterName = '<Cluster Name>';

  // Get stored credentials...
  const username = context.values.get("AtlasPublicKey");
  const password = context.values.get("AtlasPrivateKey");

  // Set the desired instance size...
  const body = {
    "replicationSpecs": [
      {
        //"numShards":1,
        "regionConfigs": [
          {
            "electableSpecs": {
              "instanceSize": "M10",
              "nodeCount": 3
            },
            "analyticsSpecs": {
              "instanceSize": "M20",
              "nodeCount": 1
            },
            "priority": 7,
            "providerName": "AZURE",
            "regionName": "US_EAST_2",
          },
        ]
      }
    ]
  };

  result = await context.functions.execute('modifyCluster', username, password, projectID, clusterName, body);
  console.log(EJSON.stringify(result));

  if (result.error) {
    return result;
  }

  return clusterName + " scaled up";
};

